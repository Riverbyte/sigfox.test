

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lista de mensajes</h1>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    



<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('message-component', [])->html();
} elseif ($_instance->childHasBeenRendered('JWDRGOE')) {
    $componentId = $_instance->getRenderedChildComponentId('JWDRGOE');
    $componentTag = $_instance->getRenderedChildComponentTagName('JWDRGOE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JWDRGOE');
} else {
    $response = \Livewire\Livewire::mount('message-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('JWDRGOE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 






<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sigfox\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>