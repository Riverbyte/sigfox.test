


<div class="pt-4 container mx-auto">

  
       
    <div class="bg-white rounded-lg shadow overflow-hidden max-w-4xl mx-auto p-4 mb-6 ">
        
        <div class="mb-4">
            <label for="device" class="form-label mb-2">Device</label>
            <input wire:model='device' id="device" class="form-control " placeholder="Device id" type="text">
        </div>

        <div class="mb-4"> 
            <label for="name" class="form-label mb-2">Device</label>
            <input wire:model='name' id="name" class="form-control " placeholder="Device name" type="text">
        </div>

        <div class="mb-4">
            <label for="description" class="form-label mb-2">description</label>
            <input wire:model='description' id="description" class="form-control " placeholder="Description" type="text">
        </div>

        <div class="mb-4">
            <label for="user" class="form-label mb-2">user</label>
            <input wire:model='user' id="user" class="form-control " placeholder="User" type="text">
        </div>

        <div>
            <?php if($accion == 'store'): ?>
                <button  wire:click='store' class="bg-blue-500 mb-2 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded ">Guardar</button>
            <?php else: ?>
                <button wire:click='update' class="bg-blue-500 mb-2 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded ">Actualizar</button>
                <button wire:click='default' class="bg-red-500 hover:bg-red-700 text-white font-bold px-4 py-2 rounded ">Cancelar</button>
            <?php endif; ?>
            
        </div>
    </div>
    
    


    <table class="bg-white rounded-lg shadow overflow-hidden max-w-4xl mx-auto ">
        <thead class="bg-gray-50 border-b border-gray-200 ">
            <tr class="text-xs font-medium text-gray-500 uppercase tracking-wider ">
                <th class="px-6 py-3">ID</th>
                <th class="px-6 py-3">device</th>
                <th class="px-6 py-3">name</th>
                <th class="px-6 py-3">description</th>
                <TH class="px-6 py-3">user</TH>
                <TH ></TH>
            </tr>
        </thead>

        <tbody class="divide-y divide-gray-200 ">
            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-gray-500 ">
                    <td class="py-2 px-6"><?php echo e($device->id); ?></td>
                    <td class="py-2 px-6">
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => ''.e(route('messages.show',$device )).'','active' => request()->routeIs('messages')]]); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('messages.show',$device )).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('messages'))]); ?>
                            <?php echo e($device->device); ?>

                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </td>
                    <td class="py-2 px-6"><?php echo e($device->name); ?></td>
                    <td class="py-2 px-6"><?php echo e($device->description); ?></td>
                    <td class="py-2 px-6"><?php echo e($device->user); ?></td>
                    <td class="py-2 px-6  ">
                        <button wire:click='edit(<?php echo e($device); ?>)' class="modal-open bg-blue-500 mb-2 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded w-full ">Editar</button>
                        <button wire:click='destroy(<?php echo e($device); ?>)' class="bg-red-500 hover:bg-red-700 text-white font-bold px-4 py-2 rounded ">Eliminar</button>
                    </td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\sigfox\resources\views/livewire/device-component.blade.php ENDPATH**/ ?>