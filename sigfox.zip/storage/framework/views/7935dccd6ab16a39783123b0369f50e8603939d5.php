 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>



    <div class="pt-4 container mx-auto">

        <button wire:click='render' id="actualiza">Click</button>
        <div class="bg-white rounded-lg shadow overflow-hidden max-w-4xl mx-auto ">
            <table class="bg-white rounded-lg shadow overflow-hidden max-w-4xl mx-auto ">
                <thead class="bg-gray-50 border-b border-gray-200 ">
                    <tr class="text-xs font-medium text-gray-500 uppercase tracking-wider ">
                        <th class="px-6 py-3">ID</th>
                        <th class="px-6 py-3">name</th>
                        <th class="px-6 py-3">DEVICE</th>
                        <th class="px-6 py-3">DATA</th>
                        <TH class="px-6 py-3">TIME</TH>
                    </tr>
                </thead>
        
                <tbody class="divide-y divide-gray-200 ">
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-gray-500 ">
                            <td class="py-2 px-6"><?php echo e($message->ID); ?></td>
                            <td class="py-2 px-6"><?php echo e($message->NAME); ?></td>
                            <td class="py-2 px-6"><?php echo e($message->DEVICE); ?></td>
                            <td class="py-2 px-6"><?php echo e($message->DATA); ?></td>
                            <td class="py-2 px-6"><?php echo e($message->TIME); ?></td>
                            
                            
                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                </tbody>
            </table>

            <div class="bg-gray-100 px-6 py-4 border-t border-gray-200 ">
                <?php echo e($messages->links()); ?>

            </div>
        </div>
    </div>


    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\laravel\sigfox\resources\views/messages/show.blade.php ENDPATH**/ ?>