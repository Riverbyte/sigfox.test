<?php    
    header("content-type: text/xml");    
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";

?>
<Response>    
    <Say>Hello world. </Say>
</Response><?php /**PATH C:\xampp\htdocs\laravel\sigfox\resources\views/twilio/callmessage.blade.php ENDPATH**/ ?>