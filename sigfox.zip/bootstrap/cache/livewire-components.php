<?php return array (
  'device-component' => 'App\\Http\\Livewire\\DeviceComponent',
  'devices-admin-component' => 'App\\Http\\Livewire\\DevicesAdminComponent',
  'message-component' => 'App\\Http\\Livewire\\MessageComponent',
  'users-component' => 'App\\Http\\Livewire\\UsersComponent',
);