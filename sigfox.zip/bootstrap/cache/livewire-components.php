<?php return array (
  'device-component' => 'App\\Http\\Livewire\\DeviceComponent',
  'devicesadmin' => 'App\\Http\\Livewire\\Devicesadmin',
  'message-component' => 'App\\Http\\Livewire\\MessageComponent',
);